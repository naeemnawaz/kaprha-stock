from django.db import models
from datetime import date



class Product(models.Model):
    name = models.CharField(max_length=255)
    color = models.CharField(max_length=50)
    variety = models.CharField(max_length=100)
    quantity = models.IntegerField()
    kg = models.FloatField()


class Shop(models.Model):
    name = models.CharField(max_length=255)
    color = models.CharField(max_length=50)
    variety = models.CharField(max_length=100)
    quantity = models.IntegerField()
    kg = models.FloatField()

class Shopsales(models.Model):
    name = models.CharField(max_length=255)
    color = models.CharField(max_length=50)
    variety = models.CharField(max_length=100)
    quantity = models.IntegerField()
    kg = models.FloatField()
    price = models.FloatField(default=0)
    date = models.DateField(("Date"), default=date.today)

class Stocksales(models.Model):
    name = models.CharField(max_length=255)
    color = models.CharField(max_length=50)
    variety = models.CharField(max_length=100)
    quantity = models.IntegerField()
    kg = models.FloatField()
    price = models.FloatField(default=0)
    date = models.DateField(("Date"), default=date.today)


