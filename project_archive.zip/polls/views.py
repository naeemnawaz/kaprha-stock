from django.shortcuts import render , redirect
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.models import User ,auth
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count
from .models import Product , Shop, Shopsales, Stocksales
from django.shortcuts import get_object_or_404
from django.contrib.auth import logout
from .forms import ProductUpdateForm ,Updateshopsales,Updatestocksales,Updateshop
from django.db.models import Sum
from django.db.models.functions import TruncMonth
# Create your views here.
def login(request):
    if request.method=='POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            print('login successful')
            return redirect("stock")
        else:
        	print("not login")
    print("not login last page reddicrt")
    return render(request,'login.html')
def logout_view(request):
    logout(request)
    return render(request,'home.html')
def home(request):
    return render(request,'home.html')

#@login_required
def entry(request):
    if request.method=='POST':
        name = request.POST['name']
        color = request.POST['color']
        variety = request.POST['variety']
        quantity = request.POST['quantity']
        kg = request.POST['kg']
        
        # Create and save a new Product instance
        new_product = Product(
            name=name,
            color=color,
            variety=variety,
            quantity=quantity,
            kg=kg
        )
        new_product.save()
        messages.success(request, 'New product in stock saved successfully.')


    return render(request,'entry.html')
@login_required
def maindash(request):
    shopsalesobj = Shopsales.objects.all()
    shopobj = Shop.objects.all()
    stocksalesobj = Stocksales.objects.all()
    stockobj = Product.objects.all()
    monthly_totals_stock = Stocksales.objects.annotate(month=TruncMonth('date')).values('month').annotate(total_price=Sum('price'))
    for value in monthly_totals_stock:
        print(value)
    # Convert the queryset to a dictionary for easy access
    monthly_totals_dict = {item['month'].strftime('%B %Y'): item['total_price'] for item in monthly_totals_stock}
    monthly_totals = Stocksales.objects.annotate(month=TruncMonth('date')).values('month').annotate(total_price=Sum('price'))
    for value in monthly_totals:
        print('this is list',value)
    qrstock = 0
    qsstock = 0 
    krstock = 0 
    ksstock = 0 
    qrshop = 0
    qsshop = 0 
    krshop = 0 
    ksshop = 0 
    pricestock = 0 
    priceshop = 0 

    for value in stockobj:
        qrstock = qrstock + value.quantity
        krstock = krstock + value.kg 
    for value in stocksalesobj:
        pricestock = pricestock + value.price
        qsstock = qsstock + value.quantity
        ksstock = ksstock + value.kg 
    for value in shopobj:
        qrshop = qrshop + value.quantity
        krshop = krshop + value.kg 
    for value in shopsalesobj:
        priceshop = priceshop + value.price 
        qsshop = qsshop + value.quantity
        ksshop = ksshop + value.kg 
    total_remain_quantity = qrstock + qrshop
    total_sold_quantity = qsstock + qsshop
    total_remain_kg = krstock + krshop
    total_sold_kg = ksshop +ksstock

    objects = {'qrstock':qrstock,'krstock':krstock,'qsstock':qsstock,'ksstock':ksstock,'qrshop':qrshop,
    'krshop':krshop,'qsshop':qsshop,'ksshop':ksshop ,'total_remain_quantity':total_remain_quantity,
    'total_sold_quantity':total_sold_quantity,'total_remain_kg':total_remain_kg
    ,'total_sold_kg':total_sold_kg,'pricestock':pricestock,'priceshop':priceshop,'monthly_totals_dict':monthly_totals_dict}

    return render(request,'maindash.html',objects)
@login_required
def stock(request):
    products = Product.objects.all()
    return render(request, 'stock.html', {'products': products})
def shop(request):
    objects = Shop.objects.all()
    return render(request,'shop.html',{'objects':objects})
def send_to_shop(request,pk):
    if request.method=='POST':
        name = request.POST['name']
        color = request.POST['color']
        variety = request.POST['variety']
        quantity = request.POST['quantity']
        kg = request.POST['kg']
        obj = Shop.objects.filter(name=name).first()
        if obj is not None:
            shopkg = float(obj.kg) + float(kg)
            shopquantity = int(obj.quantity) + int(quantity)
            stockobj = Product.objects.filter(name=name).first()
            stockquantity = int(stockobj.quantity) - int(quantity)
            stockkg = float(stockobj.kg) - float(kg)
            Product.objects.filter(name=name).update(quantity=stockquantity,kg=stockkg)
            Shop.objects.filter(name=name).update(quantity=shopquantity, kg=shopkg)
            messages.success(request, 'Product updated in shop successfully.')
            objects = Shop.objects.all()
            return render(request,'shop.html',{'objects':objects})
        else:
            new_product = Shop(
            name=name,
            color=color,
            variety=variety,
            quantity=quantity,
            kg=kg
            )
            new_product.save()
            messages.success(request, 'New Product in Shop successfully.')
            objects = Shop.objects.all()
            stockobj = Product.objects.filter(name=name).first()
            stockquantity = int(stockobj.quantity) - int(quantity)
            stockkg = float(stockobj.kg) - float(kg)
            Product.objects.filter(name=name).update(quantity=stockquantity,kg=stockkg)
            return render(request,'shop.html',{'objects':objects})
    objects = Product.objects.filter(pk=pk).first()
    return render(request,'send_to_shop.html',{'objects':objects})
def purchesstock(request,pk):
    if request.method=='POST':
        name = request.POST['name']
        color = request.POST['color']
        variety = request.POST['variety']
        quantity = request.POST['quantity']
        kg = request.POST['kg']
        price = request.POST['price']
        new_product = Stocksales(
        name=name,
        color=color,
        variety=variety,
        quantity=quantity,
        kg=kg,
        price=price
        )
        stockobj = Product.objects.filter(name=name).first()
        if stockobj is not None:
            stockquantity = int(stockobj.quantity) - int(quantity)
            stockkg = float(stockobj.kg) - float(kg)
            Product.objects.filter(name=name).update(quantity=stockquantity,kg=stockkg)

        print("this is in ")
        new_product.save()
        messages.success(request, 'some new product are sold successfully.')
        objects = Stocksales.objects.all()
        return render(request,'stocksales.html',{'objects':objects})
    print("endddddddddd")
    objects = Product.objects.filter(pk=pk).first()
    return render(request,'purchesstock.html',{'objects':objects})
def purchesshop(request,pk):
    if request.method=='POST':
        name = request.POST['name']
        color = request.POST['color']
        variety = request.POST['variety']
        quantity = request.POST['quantity']
        kg = request.POST['kg']
        price = request.POST['price']
        new_product = Shopsales(
        name=name,
        color=color,
        variety=variety,
        quantity=quantity,
        kg=kg,
        price=price
        )
        new_product.save()
        stockobj = Shop.objects.filter(name=name).first()
        if stockobj is not None:
            stockquantity = int(stockobj.quantity) - int(quantity)
            stockkg = float(stockobj.kg) - float(kg)
            Shop.objects.filter(name=name).update(quantity=stockquantity,kg=stockkg)
        messages.success(request, 'some new product are sold successfully.')
        objects = Shopsales.objects.all()
        return render(request,'shopsales.html',{'objects':objects})
    print("endddddddddd")
    objects = Shop.objects.filter(pk=pk).first()
    return render(request,'purchesshop.html',{'objects':objects})
def delete(request, pk):
    obj = get_object_or_404(Product, pk=pk)  # Replace with your actual model name
    obj.delete()
    products = Product.objects.all()
    return render(request, 'stock.html', {'products': products})
def deletestocksales(request, pk):
    obj = get_object_or_404(Stocksales, pk=pk)  # Replace with your actual model name
    obj.delete()
    objects = Stocksales.objects.all()
    return render(request,'stocksales.html',{'objects':objects})
def deleteshop(request, pk):
    obj = get_object_or_404(Shop, pk=pk)  # Replace with your actual model name
    obj.delete()
    objects = Shop.objects.all()
    return render(request,'shop.html',{'objects':objects})
def deleteshopsales(request, pk):
    obj = get_object_or_404(Shopsales, pk=pk)  # Replace with your actual model name
    obj.delete()
    objects = Shopsales.objects.all()
    return render(request, 'shopsales.html', {'products': objects})
def update(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if request.method == 'POST':
        form = ProductUpdateForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            products = Product.objects.all()
            return render(request,'stock.html',{'products':products})
    else:
        form = ProductUpdateForm(instance=product)

    return render(request, 'update.html', {'form': form})
def updatestocksales(request, pk):
    product = get_object_or_404(Stocksales, pk=pk)
    if request.method == 'POST':
        form = Updatestocksales(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'Stock Sales is updated successfully.')
            #products = Stocksales.objects.all()
            #return render(request,'stocksales.html',{'products':products})
    else:
        form = Updatestocksales(instance=product)
    
    return render(request, 'update.html', {'form': form})
def updateshop(request, pk):
    product = get_object_or_404(Shop, pk=pk)

    if request.method == 'POST':
        form = Updateshop(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'Shop products are updated successfully.')
            #products = Shop.objects.all()
            #return render(request,'shop.html',{'products':products})
    else:
        form = Updateshop(instance=product)
    return render(request, 'update.html', {'form': form})
def updateshopsales(request, pk):
    product = get_object_or_404(Shopsales, pk=pk)

    if request.method == 'POST':
        form = Updateshopsales(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'Shop Sales are updated successfully.')
            #products = Shopsales.objects.all()
            #return render(request,'stock.html',{'products':products})
    else:
        form = Updateshopsales(instance=product)

    return render(request, 'update.html', {'form': form})
def shopsales(request):
    objects = Shopsales.objects.all()
    #result = Shopsales.objects.values("quantity").annotate(total_count=Count("quantity"))
    #print(result)
    #print("quantity...........")
    quantitycount = 0 
    meterquantity = 0.0
    for value in objects:
        print(value.quantity)
        quantitycount = quantitycount + value.quantity
        print("this is value of kg",value.kg)
        meterquantity = float(meterquantity) + float(value.kg)
    return render(request,'shopsales.html',{'objects':objects,'meterquantity'
        :meterquantity,'quantitycount':quantitycount})
def stocksales(request):
    objects = Stocksales.objects.all()
    quantitycount = 0 
    meterquantity = 0.0
    for value in objects:
        print(value.quantity)
        quantitycount = quantitycount + value.quantity
        print("this is value of kg",value.kg)
        meterquantity = float(meterquantity) + float(value.kg)
    return render(request,'stocksales.html',{'objects':objects,'meterquantity'
        :meterquantity,'quantitycount':quantitycount})
