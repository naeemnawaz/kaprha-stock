from django.urls import path
from django.contrib.auth import views as auth_views

from . import views


app_name = 'polls'

urlpatterns = [
    path('', views.home, name='home'),
    path('entry/', views.entry, name='entry'),
    path('maindash/', views.maindash, name='maindash'),
    path('shop/', views.shop, name='shop'),
    path('stock/', views.stock, name='stock'),
    path('stocksales/', views.stocksales, name='stocksales'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('shopsales/', views.shopsales, name='shopsales'),
    path('send_to_shop/<int:pk>/', views.send_to_shop, name='send_to_shop'),
    path('purchesstock/<int:pk>/', views.purchesstock, name='purchesstock'),
    path('purchesshop/<int:pk>/', views.purchesshop, name='purchesshop'),
    # path('register/', views.register, name='register'),
    # path('login/', auth_views.LoginView.as_view(), name='login'),
    # path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('delete/<int:pk>/', views.delete, name='delete'),
    path('deletestocksales/<int:pk>/', views.deletestocksales, name='deletestocksales'),
    path('deleteshop/<int:pk>/', views.deleteshop, name='deleteshop'),
    path('deleteshopsales/<int:pk>/', views.deleteshopsales, name='deleteshopsales'),
    path('update/<int:pk>/', views.update, name='update'),
    path('updateshop/<int:pk>/', views.updateshop, name='updateshop'),
    path('updateshopsales/<int:pk>/', views.updateshopsales, name='updateshopsales'),
    path('updatestocksales/<int:pk>/', views.updatestocksales, name='updatestocksales'),
    #path('update/<int:pk>/', views.update, name='update'),
]