from django.contrib import admin


from .models import Product, Shop, Shopsales,Stocksales

admin.site.register(Product)
admin.site.register(Shop)
admin.site.register(Shopsales)
admin.site.register(Stocksales)
