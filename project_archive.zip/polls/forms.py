# forms.py

from django import forms
from .models import Product

class ProductUpdateForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'color', 'variety', 'quantity', 'kg']
class Updatestocksales(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'color', 'variety', 'quantity', 'kg']
class Updateshop(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'color', 'variety', 'quantity', 'kg']
class Updateshopsales(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'color', 'variety', 'quantity', 'kg']
